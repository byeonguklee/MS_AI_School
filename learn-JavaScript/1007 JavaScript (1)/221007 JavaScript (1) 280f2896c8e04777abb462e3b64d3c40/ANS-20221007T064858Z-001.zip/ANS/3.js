function isOdd(num) {
    return num % 2 == 1;
}

let number = 3
let result = isOdd(number)
console.log(result)